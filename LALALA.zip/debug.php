<?php 
$titre = 'Debug';
$nav = 'debug';
require 'header.php';
?>

<section>
</section>


<?php 
require 'footer.php';
?>