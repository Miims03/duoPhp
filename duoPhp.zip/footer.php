<footer>
    <h1>footer</h1>
</footer>
<script src="script.js"></script>
</body>
</html>